CKEDITOR.editorConfig = function (config) {
  // ... other configuration ...

  config.allowedContent = true;
}
;
